package com.senaidev.livraria.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.senaidev.livraria.entities.Editora;
import com.senaidev.livraria.repositories.EditoraRepository;

@Service
public class EditoraService {

	@Autowired
	private EditoraRepository editoraRepository;
	
	public Editora saveEditora(Editora editora) {
		return editoraRepository.save(editora);
	}
	
	public List<Editora> getALLEditora(){
		return editoraRepository.findAll();
		}
	
	public Editora getEditoraById(Long id) {
		return editoraRepository.findById(id).orElse(null);
	}
	public void deleteEditora(long id) {
		editoraRepository.deleteById(id);
	}
	
	
}
