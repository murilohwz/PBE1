package com.senaidev.livraria.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table
public class Livro {
	
	@Id
	Long id_livro;
	
	@Column
	String nome_livro;
	@Column
	String nome_autor;
	@Column
	String isbn;
	@Column
	int ano;
	@Column
	double valor;
	@Column
	int estoque;
	
	
	//Construtores
	public Livro(Long id_livro, String nome_livro, String nome_autor, String isbn, int ano, double valor, int estoque) {
		super();
		this.id_livro = id_livro;
		this.nome_livro = nome_livro;
		this.nome_autor = nome_autor;
		this.isbn = isbn;
		this.ano = ano;
		this.valor = valor;
		this.estoque = estoque;
	}
	
	//Getters e Setters
	public Long getId_livro() {
		return id_livro;
	}
	
	public void setId_livro(Long id_livro) {
		this.id_livro = id_livro;
	}
	public String getNome_livro() {
		return nome_livro;
	}
	public void setNome_livro(String nome_livro) {
		this.nome_livro = nome_livro;
	}
	public String getNome_autor() {
		return nome_autor;
	}
	public void setNome_autor(String nome_autor) {
		this.nome_autor = nome_autor;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	public int getAno() {
		return ano;
	}
	public void setAno(int ano) {
		this.ano = ano;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public int getEstoque() {
		return estoque;
	}
	public void setEstoque(int estoque) {
		this.estoque = estoque;
	}
}


