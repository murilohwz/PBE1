package com.senaidev.cadastroProduto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CadastroProdutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CadastroProdutoApplication.class, args);
	}

}
