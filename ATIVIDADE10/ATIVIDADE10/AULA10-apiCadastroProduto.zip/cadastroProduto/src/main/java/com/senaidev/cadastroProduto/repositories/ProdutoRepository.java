package com.senaidev.cadastroProduto.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.senaidev.cadastroProduto.entities.Produto;

public interface ProdutoRepository extends JpaRepository<Produto, Long>{

}
