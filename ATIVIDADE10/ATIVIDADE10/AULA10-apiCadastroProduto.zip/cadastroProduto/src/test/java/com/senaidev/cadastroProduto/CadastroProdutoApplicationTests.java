package com.senaidev.cadastroProduto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
