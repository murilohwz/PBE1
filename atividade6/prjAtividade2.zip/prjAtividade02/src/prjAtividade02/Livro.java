package prjAtividade02;

public class Livro {
	//Atributos
	public String titulo;
	public String autor;
	public int numPaginas;
	public double preco;
	
	//Construtores
	public Livro() {	
	}
	public Livro (String titulo, String autor, int numPaginas, double preco) {
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
		this.preco = preco;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}
	double desconto;
	public void aplicarDesconto() {
		System.out.println(preco = preco -15);
	}
	public void exibirInfo() {
		}

	public void getTitulo() {
		System.out.println("tituloLivro");
		
	}
	public void getAutor() {
	
		
	}
	public void getNumPaginas() {
		
		
	}
	public void getPreco() {
		
		
	}
}

