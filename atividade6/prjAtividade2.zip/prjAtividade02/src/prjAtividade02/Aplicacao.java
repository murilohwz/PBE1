package prjAtividade02;

public class Aplicacao {

	public static void main(String[] args) {
		Livro livro1 = new Livro ();
		
		
		livro1.titulo = "Joaquim o passaro";
		livro1.autor = "Cleber";
		livro1.numPaginas = 80;
		livro1.preco = 50;
		
		Livro livro2 = new Livro ("O jogo", "Fernando", 30, 60);
		Livro livro3 = new Livro ("Comeco", "Felipe", 50, 40);
		
		livro1.exibirInfo();
		livro1.tituloLivro();
		livro1.autorLivro();
		livro1.numPaginasLivro();
		livro1.precoLivro();
		livro1.exibirInfo();
		
		livro2.exibirInfo();
		livro2.tituloLivro();
		livro2.autorLivro();
		livro2.numPaginasLivro();
		livro2.precoLivro()
		livro2.exibirInfo();

		livro3.exibirInfo();
		livro3.tituloLivro();
		livro3.autorLivro();
		livro3.numPaginasLivro();
		livro3.precoLivro();
		livro3.exibirInfo();
	
	}

}
