package prjPokemonV2;

public class PokemonVoador extends Pokemon {
	//metodos
	
	public void voar() {
		System.out.println(this.getNome()+ " está voando");
   }@Override
	public void ataqueDeAsa() {
		System.out.println(this.getNome() + " está atacando com ataque de Asa");
	}
