package prjPokemonV2;

public class PokemonFogo extends Pokemon {
	//metodos
	@Override
	public void Atacar() {
		System.out.println(this.getNome() + " está atacando com bola de fogo");
		System.out.println(this.getNome() + " está atacando com explosão de fogo");
		System.out.println(this.getNome() + "está atacando com lança chamas");
	}
}
