package prjPokemonV2;

public class Pokemon {
	//Atributos 
		private String Nome;
		private String Tipo;
		private int Nivel1;
		private int Hp;
		private int Defesa;
		
		//Construtores
		
		public Pokemon () {
			
		}
		
		public Pokemon (String nome, String tipo, int nivel, int hp, int defesa) {
			this.Nome = nome;
			this.Tipo = tipo;
			this.Nivel1 = nivel;
			this.Hp = hp;
			this.Defesa = defesa;
		}
		
		//metodos Setters
		public void setNome (String nome) {
			this.Nome = nome;
		}
		public void setTipo (String tipo) {
			this.Tipo = tipo;
		}
		public void setNivel (int nivel) {
			this.Nivel1 = nivel;
		}
		
		public void setHp1 (int hp) {
			this.Hp = hp;
		}
		public void  setDefesa1 (int defesa) {
			this.Defesa = defesa;
		}
		
		//métodos
		public void Atacar () {
			System.out.println(this.Nome + " está atacando.");
		}
		public void Evoluir() {
			System.out.println(this.Nome + " evoluiu.");
		}
		public void exibirInfo() {
			System.out.println("nome: " + this.Nome);
			System.out.println("Peso: " + this.Nome);
			
		}


		public int getNivel() {
			return Nivel1;
		}

		public void setNivel1 (int nivel) {
			Nivel1 = nivel;
		}

		public int getHp() {
			return Hp;
		}

		public void setHp(int hp) {
			Hp = hp;
		}

		public int getDefesa() {
			return Defesa;
		}

		public void setDefesa(int defesa) {
			Defesa = defesa;
		}

		public String getNome() {
			return Nome;
		}

		public String getTipo() {
			return Tipo;
		}
}
