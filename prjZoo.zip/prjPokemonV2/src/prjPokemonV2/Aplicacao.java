package prjPokemonV2;

public class Aplicacao {
	public static void main(String[] args) {
		Pokemon Charmander = new Pokemon ();
		Charmander.setNome("Charmander");
		Charmander.setTipo("Fogo");
		Charmander.setNivel(1);
		Charmander.setHp1(100);
		Charmander.setDefesa1(50);
		
		Pokemon Cydaquil = new Pokemon();
		Cydaquil.setNome("Cydaquil");
		Cydaquil.setTipo("Fogo");
		Cydaquil.setNivel(2);
		Cydaquil.setHp1(200);
		Cydaquil.setDefesa1(50);
		
		Pokemon Squirtle = new Pokemon();
		Squirtle.setNome("Squirtle");
		Squirtle.setTipo("Água");
		Squirtle.setNivel(3);
		Squirtle.setHp1(300);
		Squirtle.setDefesa1(50);
		
		Pokemon Poliwag = new Pokemon();
		Poliwag.setNome("Poliwag");
	    Poliwag.setTipo("Água");
		Poliwag.setNivel(4);
		Poliwag.setHp1(400);
		Poliwag.setDefesa1(50);
		
		Pokemon Spearow = new Pokemon();
		Spearow.setNome("Spearow");
		Spearow.setTipo("Voador");
		Spearow.setNivel(5);
		Spearow.setHp1(500);
		Spearow.setDefesa1(50);
		
		Pokemon swablu = new Pokemon();
		swablu.setNome("Swablu");
		swablu.setTipo("Voador");
		swablu.setNivel(6);
		swablu.setHp1(600);
		swablu.setDefesa1(50);
		
	}	
}
