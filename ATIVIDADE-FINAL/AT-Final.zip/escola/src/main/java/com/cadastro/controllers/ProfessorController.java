package com.cadastro.controllers;

public class ProfessorController {

}
