package com.cadastro.controllers;

public class AlunoController {

}
