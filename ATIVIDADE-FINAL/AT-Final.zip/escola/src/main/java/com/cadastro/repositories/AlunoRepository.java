package com.cadastro.repositories;

public class AlunoRepository {
	@Repository
	public interface
}
