package com.cadastro.repositories;

public class ProfessorRepository {

}
