package br.com.bibiotecasenai.itens;

public class Livro {
	
	//Atributos
	private String titulo;
	private String autor;
	private int ISBN;
	private boolean disponivel;
	
	//Getters e Setters
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String autor) {
		this.autor = autor; 
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getISBN() {
		return ISBN;
	}
	public void setISBN(int ISBN) {
		this.ISBN = ISBN;
	}
	public boolean getDisponivel() {
		return disponivel;
	}
	public setDisponivel(boolean Disponivel) {
		this.Disponivel = disponivel;
	}
}
