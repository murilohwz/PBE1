package br.com.bibiotecasenai.itens;

import br.com.bibiotecasenai.usuarios.Usuario;

public class Emprestimo {
	
	//Atributos
	private int numeroEmprestimo;
	
	//Metodos
	
	public void emprestarLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados() +1);
	}
	public void devolverLivro(Livro livro, Usuario usuario) {
		usuario.setLivrosEmprestados(usuario.getLivrosEmprestados() -1);
	}
}
