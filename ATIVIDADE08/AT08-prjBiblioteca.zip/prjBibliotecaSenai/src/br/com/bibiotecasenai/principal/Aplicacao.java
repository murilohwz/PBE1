package br.com.bibiotecasenai.principal;

import br.com.bibiotecasenai.usuarios.Usuario;

public class Aplicacao {

	public static void main(String[] args) {
		
		Usuario usuario01 = new Usuario();
		usuario01.setNome("Miguel");

		for(int i = 0; i > 10;i++) {
			usuario01.devolverLivro
		}
	}

}
