package br.com.bibiotecasenai.usuarios;

public class Pessoa {
	//Atributos
	private String nome;
	private int idade;
	
	//Metodos
	// Getters e Setters
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getIdade() {
		return idade; 
	}
	
}
