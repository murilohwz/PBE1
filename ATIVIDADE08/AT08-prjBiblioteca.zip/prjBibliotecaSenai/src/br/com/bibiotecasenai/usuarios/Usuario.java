package br.com.bibiotecasenai.usuarios;

public class Usuario {
	//Atributos
	
	private int CPF;
	private int livrosEmprestados;
	
	//Getters e Setters
	
	public int getCPF() {
		return CPF;
	}
	public void setCPF(int CPF) {
		this.CPF = CPF;
	}
	public int getLivrosEmprestados() {
		return livrosEmprestados;
	}
	public void setLivrosEmprestados(int livrosEmprestados) {
		this.livrosEmprestados = livrosEmprestados; 
	}
	
	
	
	
}
