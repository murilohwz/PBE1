package br.com.bibiotecasenai.usuarios;

public class Bibliotecario extends Pessoa {
	
	//Atributos
	private String matricula;
	
	//Getters e Setters
	public String getMatricula() {
		return matricula;
	}
	
	//Metodos
	public void RealizarEmprestimo() {
		System.out.println(this.getNome() + "emprestou um livro");
	}
	public void DevolverLivro() {
		System.out.println(this.getNome() + "devolveu um livro");
	}
}
