package carro;

import java.util.Scanner;

public class carro {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.print("Informe a marca do carro: ");
		String marca = sc.next();
		
		System.out.print("Informe o modelo do carro: ");
		String modelo = sc.next();
		
		System.out.print("Informe a velocidade do carro: ");
		int velocidade = sc.nextInt();
		
		double acelerar = velocidade;
	    
	    if (acelerar > velocidade) {
	    	
	    	acelerar = acelerar +(velocidade);
	    	System.out.print("A velocidade do carro é: " + acelerar);
	    }
	    	else {
	    		
	    }
	    
	
	
		
		
		
	}

}
