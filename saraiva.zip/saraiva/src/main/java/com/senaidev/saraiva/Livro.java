package com.senaidev.saraiva;

public class Livro {
	
	//Atributos
	private long id_livro;
	private String descricao;
	private String isbn;
	
	//Construtores
	public Livro() {
		
	}
	public Livro(long id_livro, String descricao, String isbn) {
		
	}
	
	//Getters e Setters
	public long getId_livro() {
		return id_livro;
	}
	public void setId_livro(long id_livro) {
		this.id_livro = id_livro;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}
	
	
}
