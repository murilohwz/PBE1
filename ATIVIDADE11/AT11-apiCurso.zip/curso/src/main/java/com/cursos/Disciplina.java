package com.cursos;

public class Disciplina {
	
	//Atributos
	private int id_instrutor;
	private String nome;
	private String telefone;
	private String email;
	private String area;
	private String experiencia;
	
	//Construtores
	public Disciplina() {
		
	}
	
	public Disciplina (int id_instrutor, String nome, String telefone, String email, String area, String experiencia) {
		
	}
	
	//Getters e Setters
	public int getId_instrutor() {
		return id_instrutor;
	}

	public void setId_instrutor(int id_instrutor) {
		this.id_instrutor = id_instrutor;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getExperiencia() {
		return experiencia;
	}

	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}
	
	
}
