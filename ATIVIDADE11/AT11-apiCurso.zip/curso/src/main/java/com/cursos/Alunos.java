package com.cursos;

public class Alunos {
	
	//Atributos
	private int id_alunos;
	private String nome;
	private String telefone;
	private String email;
	private int matricula;
	private String historico;
	
	//Construtores
	public Alunos() {
		
	}
	
	//Getters e Setters
	public Alunos(int id_alunos, String nome, String telefone, int matricula, String historico) {
		
	}

	public int getId_alunos() {
		return id_alunos;
	}

	public void setId_alunos(int id_alunos) {
		this.id_alunos = id_alunos;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getMatricula() {
		return matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getHistorico() {
		return historico;
	}

	public void setHistorico(String historico) {
		this.historico = historico;
	}
	
	
}
