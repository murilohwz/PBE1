package com.cursos;

public class Cursos {
	
	//Atributos
	private int id_curso;
	private String titulo;
	private double carga_horaria;
	private String descricao;
	private double nivel;
	
	//Construtores
	public Cursos() {
		
	}
	public Cursos(int id_curso, String titulo, double carga_horaria, String descricao, double nivel) {
		
	}
	
	//Getters e Setters
	public int getId_curso() {
		return id_curso;
	}
	public void setId_curso(int id_curso) {
		this.id_curso = id_curso;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public double getCarga_horaria() {
		return carga_horaria;
	}
	public void setCarga_horaria(double carga_horaria) {
		this.carga_horaria = carga_horaria;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getNivel() {
		return nivel;
	}
	public void setNivel(double nivel) {
		this.nivel = nivel;
	}
	
	
}
