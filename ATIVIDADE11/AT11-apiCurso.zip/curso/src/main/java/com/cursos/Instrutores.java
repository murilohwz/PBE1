package com.cursos;

public class Instrutores {
	
	//Atributos
	private int id_instrutores;
	private String nome;
	private String telefone;
	private String email;
	private String area;
	private String experiencia;
	
	//Construtores
	public Instrutores() {
		
	}
	public Instrutores(int id_instrutores, String nome, String telefone, String email, String area, String experiencia) {
		
	}
	
	//Getters e Setters
	public int getId_instrutores() {
		return id_instrutores;
	}
	public void setId_instrutores(int id_instrutores) {
		this.id_instrutores = id_instrutores;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getExperiencia() {
		return experiencia;
	}
	public void setExperiencia(String experiencia) {
		this.experiencia = experiencia;
	}
	
	
}
