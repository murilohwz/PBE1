package com.cursos;

import java.util.Date;

public class Turma {
	
	//Atributos
	private Date data_inicio;
	private Date data_termino;
	private double horario;
	private double numero_vagas;
	
	//Construtores
	public Turma() {
		
	}
	
	public Turma(Date data_inicio, Date data_termino, double horario, double numero_vagas) {
		
	}
	
	//Getters e Setters
	public Date getData_inicio() {
		return data_inicio;
	}

	public void setData_inicio(Date data_inicio) {
		this.data_inicio = data_inicio;
	}

	public Date getData_termino() {
		return data_termino;
	}

	public void setData_termino(Date data_termino) {
		this.data_termino = data_termino;
	}

	public double getHorario() {
		return horario;
	}

	public void setHorario(double horario) {
		this.horario = horario;
	}

	public double getNumero_vagas() {
		return numero_vagas;
	}

	public void setNumero_vagas(double numero_vagas) {
		this.numero_vagas = numero_vagas;
	}
	
	
}
