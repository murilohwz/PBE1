package com.cadastro.entities;

public class Telefone {
	
	//Atributos
	private long id_telefone;
	private String ddd;
	private int numero_telefone;
	private String tipo;
	
	//Construtores
	public Telefone() {
		
	}
	public Telefone(long id_telefone, String ddd, int numero_telefone, String tipo) {
		this.id_telefone = id_telefone;
		this.ddd = ddd;
		this.numero_telefone = numero_telefone;
		this.tipo = tipo;
	}
	public long getId_telefone() {
		return id_telefone;
	}
	public void setId_telefone(long id_telefone) {
		this.id_telefone = id_telefone;
	}
	public String getDdd() {
		return ddd;
	}
	public void setDdd(String ddd) {
		this.ddd = ddd;
	}
	public int getNumero_telefone() {
		return numero_telefone;
	}
	public void setNumero_telefone(int numero_telefone) {
		this.numero_telefone = numero_telefone;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
	
}
