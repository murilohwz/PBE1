package com.cadastro.services;

public class EnderecoService {

}
