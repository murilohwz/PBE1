package com.cadastro.repositories;

public class TelefoneRepository {

}
