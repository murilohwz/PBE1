package com.cadastro.repositories;

public class EnderecoRepository {

}
