package com.cadastro.repositories;

public class ClienteRepository {

}
