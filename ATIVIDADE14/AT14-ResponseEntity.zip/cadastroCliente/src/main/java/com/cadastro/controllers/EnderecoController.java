package com.cadastro.controllers;

public class EnderecoController {

}
