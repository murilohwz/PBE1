package com.cadastro.entities;

public class Endereco {
	
	//Atributos
	private long id_endereco;
	private String rua;
	private int numero_casa;
	private String bairro;
	private String cidade;
	private String estado;
	
	//Construtores
	public Endereco() {
		
	}
	public Endereco(long id_endereco, String rua, int numero_casa, String bairro, String cidade, String estado) {
		this.id_endereco = id_endereco;
		this.rua = rua;
		this.numero_casa = numero_casa;
		this.bairro = bairro;
		this.cidade = cidade;
		this.estado = estado;
		
		
	}
	public long getId_endereco() {
		return id_endereco;
	}
	public void setId_endereco(long id_endereco) {
		this.id_endereco = id_endereco;
	}
	public String getRua() {
		return rua;
	}
	public void setRua(String rua) {
		this.rua = rua;
	}
	public int getNumero_casa() {
		return numero_casa;
	}
	public void setNumero_casa(int numero_casa) {
		this.numero_casa = numero_casa;
	}
	public String getBairro() {
		return bairro;
	}
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
}
