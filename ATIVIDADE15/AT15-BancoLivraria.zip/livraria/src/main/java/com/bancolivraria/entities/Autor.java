package com.bancolivraria.entities;

public class Autor {

}
